from pyrogram import Client, filters
import requests
import time

async def sk_check(Client, chat_id, sec, time_start):
    try:
        skchk_url = 'https://api.stripe.com/v1/tokens'
        skchk_payload = {
            'card[number]': '5278540001668044',
            'card[exp_month]': '10',
            'card[exp_year]': '2024',
            'card[cvc]': '252'
        }

        skchk_headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': f'Bearer {sec}'
        }

        skchk_response = requests.post(skchk_url, data=skchk_payload, headers=skchk_headers)
        skchk_result = skchk_response.json()

        error_info = skchk_result.get('error', {})
        error_code = error_info.get('code', '')

        if error_code == 'api_key_expired':
            response = f"INVALID SK ❌\nSK -» {sec}\nResponse -» {error_info.get('message', '')}\nChecked by -» {chat_id}"
            await Client.send_message(chat_id, text=response)
            return

        balance_url = 'https://api.stripe.com/v1/balance'
        balance_headers = {
            'Authorization': f'{sec}:'
        }

        balance_response = requests.get(balance_url, headers=balance_headers)
        balance_result = balance_response.json()

        curr = balance_result.get('currency', '')
        balance = balance_result.get('available', [{}])[0].get('amount', '')
        pending = balance_result.get('pending', [{}])[0].get('amount', '')

        time_end = time.time()
        execution_time = time_end - time_start

        if 'api_key_expired' in error_code:
            response = f"INVALID SK ❌\nSK -» {sec}\nResponse -» {error_info.get('message', '')}\nChecked by -» {chat_id}"
            await Client.send_message(chat_id, text=response)
        elif error_code == 'invalid_request_error' and 'Invalid API Key provided' in error_info.get('message', ''):
            response = f"INVALID KEY ❌\nSK -» {sec}\nResponse -» {error_info.get('message', '')}\nChecked by -» {chat_id}"
            await Client.send_message(chat_id, text=response)
        elif 'rate_limit' in skchk_result.get('message', ''):
            response = f"VALID SK KEY ✅\nSK -» {sec}\nResponse -» {skchk_result.get('message', '')}\nChecked by -» {chat_id}\nRate Limit ⚠️"
            await Client.send_message(chat_id, text=response)

    except Exception as e:
        print("Error in sk_check:", e)


@Client.on_message(filters.regex(r'^(\/sk|!sk|\.sk)'))
async def sk_command(Client, message):
    try:
        time_start = time.time()
        if not (argumentos := message.text.split(' ', 1)):
            await message.reply_text('<i>❌ Incorrect format. Usage: /sk [sk]</i>')
            return

        api_key = argumentos[1].strip()
        chat_id = message.chat.id
        await sk_check(Client, chat_id, api_key, time_start)

    except Exception as e:
        print("Error in sk_command:", e)
