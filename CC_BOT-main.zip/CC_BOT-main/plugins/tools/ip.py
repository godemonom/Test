import requests
from pyrogram import Client, filters

@Client.on_message(filters.command("ip"))
async def cmds(client, message):
    try:
        zipcode = message.text[len('/ip '):]
        if not zipcode:
            await message.reply("<b>⎚ Usar <code>/ip 1.1.1.1</code><b>")
            return

        spli = zipcode.split()
        ips = spli[0]
        if not spli:
            await message.reply_text(f'<b>⎚ Usar <code>/ip 1.1.1.1</code><b>')
            return

        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Language': 'es-ES,es;q=0.9',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
        }

        response = requests.get(f'http://ipwho.is/{ips}', headers=headers, verify=False).json()
        ip = response.get('ip', '')
        flag = response.get('flag', {}).get('emoji', '')
        connection = response.get('connection', {}).get('asn', '')
        connection1 = response.get('connection', {}).get('org', '')
        connection2 = response.get('connection', {}).get('isp', '')
        connection3 = response.get('connection', {}).get('domain', '')
        timezone = response.get('timezone', {}).get('id', '')
        timezone1 = response.get('timezone', {}).get('abbr', '')
        timezone2 = response.get('timezone', {}).get('is_dst', '')
        timezone3 = response.get('timezone', {}).get('utc', '')
        timezone4 = response.get('timezone', {}).get('current_time', '')

        await message.reply(f"""<b>
  IP Address
 ip:  <code>{ip}</code> ✅
━━━━━━━━━━━━━━
<i>City:</i> <code>{timezone} {flag}</code>
<i>Ips:</i> <code>{connection2}</code>
<i>Abbr :</i> <code>{timezone1}</code>
<i>Domain:</i> <code>{connection3}</code>
<i>Org:</i> <code>{connection1}</code>
𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲: @{message.from_user.username}
━━━━━━━━━━━━━━
</b>""")
    except Exception as e:
        print(f"Error: {str(e)}")

# Assuming you have initialized and run the Client somewhere in your code
